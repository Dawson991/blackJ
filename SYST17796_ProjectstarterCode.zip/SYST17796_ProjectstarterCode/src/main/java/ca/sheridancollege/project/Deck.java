package ca.sheridancollege.project;

import java.util.Collections;

public class Deck extends GroupOfCards {

    public Deck() {
        super(52); 
        initializeDeck(); 
    }

    private void initializeDeck() {
        
        for (PlayingCard.Suit suit : PlayingCard.Suit.values()) {
            for (PlayingCard.Rank rank : PlayingCard.Rank.values()) {
                addCard(new PlayingCard(rank, suit));
            }
        }
    }

    public void addCard(Card card) {
        if (getCards() != null) { // Check if the ArrayList is initialized
            getCards().add(card);
        }
    }

    @Override
    public void shuffle() {
        Collections.shuffle(getCards());
    }

    public PlayingCard dealCard() {
            return (PlayingCard) getCards().remove(0);
    }
}
